const default_image = "/build/assets/default-image-C-yGWlgr.jpg";
export {
  default_image as d
};
