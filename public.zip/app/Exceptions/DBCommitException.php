<?php

namespace App\Exceptions;

use Exception;

class DBCommitException extends Exception
{
    //
}
