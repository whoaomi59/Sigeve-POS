<?php

namespace App\Exceptions;

use Exception;

class UnitTypeNotFoundException extends Exception
{
    //
}
