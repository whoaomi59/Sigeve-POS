<?php

namespace App\Exceptions;

use Exception;

class SalaryAlreadyPaidException extends Exception
{
    //
}
