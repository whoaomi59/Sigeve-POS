<?php

namespace App\Exceptions;

use Exception;

class SupplierNotFoundException extends Exception
{
    //
}
