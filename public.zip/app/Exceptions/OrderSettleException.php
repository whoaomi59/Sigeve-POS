<?php

namespace App\Exceptions;

use Exception;

class OrderSettleException extends Exception
{
    //
}
