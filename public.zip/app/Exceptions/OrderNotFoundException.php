<?php

namespace App\Exceptions;

use Exception;

class OrderNotFoundException extends Exception
{
    //
}
