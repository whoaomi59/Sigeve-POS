<?php

namespace App\Exceptions;

use Exception;

class ExpenseNotFoundException extends Exception
{
    //
}
