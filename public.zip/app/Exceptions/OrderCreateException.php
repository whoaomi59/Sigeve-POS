<?php

namespace App\Exceptions;

use Exception;

class OrderCreateException extends Exception
{
    //
}
