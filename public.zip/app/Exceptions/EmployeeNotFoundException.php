<?php

namespace App\Exceptions;

use Exception;

class EmployeeNotFoundException extends Exception
{
    //
}
