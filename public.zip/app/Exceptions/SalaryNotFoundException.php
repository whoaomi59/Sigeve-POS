<?php

namespace App\Exceptions;

use Exception;

class SalaryNotFoundException extends Exception
{
    //
}
