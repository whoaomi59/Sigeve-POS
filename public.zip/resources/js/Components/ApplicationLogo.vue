<template>
    <div class="flex justify-items-center justify-center">
        <img :src="Logo" alt="Sigeve-POS" class="h-20" />
    </div>
</template>

<script setup>
import Logo from "@/assets/img/logo-sigeve-pos.png";
</script>
