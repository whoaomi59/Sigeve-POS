<template>
    <div class="buy-now">
        <a
            href="https://themeselection.com/item/sneat-bootstrap-html-admin-template/"
            target="_blank"
            class="btn btn-danger btn-buy-now"
        >Upgrade to Pro</a
        >
    </div>
</template>
